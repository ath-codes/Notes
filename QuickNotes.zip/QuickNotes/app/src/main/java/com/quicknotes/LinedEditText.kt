package com.quicknotes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText

/** مربع كتابة بخلفية مسطرة: ارتفاع السطر ثابت فتتطابق الكتابة مع الخطوط تماما. */
class LinedEditText(c: Context) : EditText(c) {
    private val rowPx = c.dp(40)   // ارتفاع السطر (غيّر الرقم لو عايز أوسع أو أضيق)

    private val linePaint = Paint().apply {
        color = Ui.LINE
        strokeWidth = c.dp(1).toFloat().coerceAtLeast(1f)
    }

    init {
        background = null
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
        setTextColor(Ui.INK)
        setHintTextColor(Ui.HINT)
        hint = "اكتب هنا…"
        gravity = Gravity.TOP
        textAlignment = View.TEXT_ALIGNMENT_TEXT_START
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        if (Build.VERSION.SDK_INT >= 28) {
            isFallbackLineSpacing = false   // يمنع الخط العربي الاحتياطي من تكبير ارتفاع السطر
            setLineHeight(rowPx)
        } else {
            setLineSpacing(c.dp(14).toFloat(), 1f)
        }
        setPadding(c.dp(20), c.dp(8), c.dp(20), c.dp(120))
    }

    override fun onDraw(canvas: Canvas) {
        val lay = layout
        if (lay != null) {
            val off = context.dp(8)
            // خط تحت كل سطر كتابة فعلي (يتبع مكان النص بالظبط)
            var y = 0f
            for (i in 0 until lineCount) {
                y = getLineBounds(i, null).toFloat() + off
                canvas.drawLine(0f, y, width.toFloat(), y, linePaint)
            }
            // باقي الصفحة الفاضية
            val step = if (Build.VERSION.SDK_INT >= 28) rowPx.toFloat()
            else (lay.getLineBottom(0) - lay.getLineTop(0)).toFloat()
            y += step
            while (y < height) {
                canvas.drawLine(0f, y, width.toFloat(), y, linePaint)
                y += step
            }
        }
        super.onDraw(canvas)
    }
}
