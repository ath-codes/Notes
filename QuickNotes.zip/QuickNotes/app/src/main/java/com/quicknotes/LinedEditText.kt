package com.quicknotes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText

/** مربع كتابة بخلفية مسطرة: السطور واسعة وتملأ الشاشة كلها. */
class LinedEditText(c: Context) : EditText(c) {
    private val linePaint = Paint().apply {
        color = Ui.LINE
        strokeWidth = c.dp(1).toFloat().coerceAtLeast(1f)
    }

    init {
        background = null
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
        setTextColor(Ui.INK)
        setHintTextColor(Ui.HINT)
        hint = "اكتب هنا…"
        gravity = Gravity.TOP
        textAlignment = View.TEXT_ALIGNMENT_TEXT_START
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        setLineSpacing(c.dp(14).toFloat(), 1f)   // مسافة واسعة بين السطور
        setPadding(c.dp(20), c.dp(8), c.dp(20), c.dp(120))
    }

    override fun onDraw(canvas: Canvas) {
        val step = lineHeight.toFloat()
        var y = getLineBounds(0, null).toFloat() + context.dp(6)
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, linePaint)
            y += step
        }
        super.onDraw(canvas)
    }
}
