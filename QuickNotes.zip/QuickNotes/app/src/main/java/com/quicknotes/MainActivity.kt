package com.quicknotes

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var note = Note()
    private lateinit var lined: LinedEditText
    private lateinit var linedScroll: ScrollView
    private lateinit var tableScroll: ScrollView
    private lateinit var tableBox: LinearLayout
    private lateinit var toggleBtn: TextView
    private val cells = ArrayList<List<EditText>>()
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BAR
        window.navigationBarColor = Ui.PAGE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContentView(buildUi())
        val id = intent.getLongExtra("id", -1L)
        load(NoteStore.get(this, id) ?: Note())
    }

    // ---------- واجهة ----------
    private fun iconBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        gravity = Gravity.CENTER
        setTextColor(Ui.INK)
        minWidth = dp(50)
        minHeight = dp(52)
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.PAGE)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            setPadding(dp(8), 0, dp(8), 0)
        }
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(iconBtn("📚") { save(); startActivity(Intent(this, NotesListActivity::class.java)) })
        bar.addView(iconBtn("＋") { save(); load(Note()) })
        toggleBtn = iconBtn("▦") { hideKeyboard(); setMode(1 - note.mode) }
        bar.addView(toggleBtn)
        bar.addView(iconBtn("📌") { openSticky() })

        linedScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
        }
        lined = LinedEditText(this)
        linedScroll.addView(lined, LinearLayout.LayoutParams(MATCH, WRAP))

        tableScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        tableBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(120))
        }
        val addRow = TextView(this).apply {
            text = "＋ صف جديد"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Ui.INK)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
            setOnClickListener { addRow(null) }
        }
        tableBox.addView(addRow, LinearLayout.LayoutParams(MATCH, WRAP))
        tableScroll.addView(tableBox, LinearLayout.LayoutParams(MATCH, WRAP))

        val frame = FrameLayout(this)
        frame.addView(linedScroll, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(tableScroll, FrameLayout.LayoutParams(MATCH, MATCH))

        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(52)))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return root
    }

    private fun addRow(vals: List<String>?) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            isBaselineAligned = false
        }
        val es = (0 until 3).map { i ->
            EditText(this).apply {
                background = rounded(Ui.PAGE, 0f, dp(1), Ui.GRID)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setTextColor(Ui.INK)
                gravity = Gravity.TOP
                textAlignment = View.TEXT_ALIGNMENT_TEXT_START
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minHeight = dp(52)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setText(vals?.getOrNull(i) ?: "")
            }.also { row.addView(it, LinearLayout.LayoutParams(0, MATCH, 1f)) }
        }
        cells.add(es)
        tableBox.addView(row, tableBox.childCount - 1, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    // ---------- المحتوى ----------
    private fun load(n: Note) {
        note = n
        lined.setText(n.text)
        tableBox.removeViews(0, tableBox.childCount - 1)
        cells.clear()
        val rows = if (n.table.isEmpty()) List(7) { listOf("", "", "") } else n.table
        rows.forEach { addRow(it) }
        setMode(n.mode)
        if (n.isEmpty()) {
            lined.postDelayed({
                lined.requestFocus()
                getSystemService(InputMethodManager::class.java).showSoftInput(lined, 0)
            }, 250)
        }
    }

    private fun setMode(m: Int) {
        note.mode = m
        linedScroll.visibility = if (m == 0) View.VISIBLE else View.GONE
        tableScroll.visibility = if (m == 1) View.VISIBLE else View.GONE
        toggleBtn.text = if (m == 0) "▦" else "≡"
    }

    private fun save() {
        note.text = lined.text.toString()
        note.table = cells.map { r -> r.map { it.text.toString() } }
        if (note.isEmpty()) NoteStore.delete(this, note.id) else NoteStore.save(this, note)
    }

    private fun hideKeyboard() {
        getSystemService(InputMethodManager::class.java)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    // ---------- الملاحظة اللاصقة ----------
    private fun openSticky() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «الظهور فوق التطبيقات» ثم ارجع واضغط 📌 تاني", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        var asked = false
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            asked = true
        }
        startForegroundService(Intent(this, StickyService::class.java))
        if (!asked) moveTaskToBack(true)   // نرجع للشاشة الرئيسية عشان الملاحظة تظهر
    }

    // ---------- دورة الحياة ----------
    override fun onPause() {
        save()
        super.onPause()
    }

    override fun onStop() {
        stoppedAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onRestart() {
        super.onRestart()
        // لو رجعت بعد أكتر من دقيقتين تفتح صفحة جديدة فاضية
        if (stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > 120_000) {
            load(Note())
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = intent.getLongExtra("id", -1L)
        if (id > 0) {
            save()
            load(NoteStore.get(this, id) ?: Note())
        }
    }
}
