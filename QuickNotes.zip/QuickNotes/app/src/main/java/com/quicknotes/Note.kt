package com.quicknotes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    var id: Long = System.currentTimeMillis(),
    var text: String = "",
    var table: List<List<String>> = emptyList(),
    var mode: Int = 0,          // 0 = صفحة مسطرة ، 1 = جدول
    var updated: Long = 0L
) {
    fun isEmpty() = text.isBlank() && table.all { r -> r.all { it.isBlank() } }

    fun title(): String {
        val line = text.lines().firstOrNull { it.isNotBlank() }?.trim()
        if (line != null) return line.take(60)
        val cell = table.flatten().firstOrNull { it.isNotBlank() }?.trim()
        if (cell != null) return "▦ " + cell.take(50)
        return "ملاحظة فارغة"
    }
}

object NoteStore {
    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("notes", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): MutableList<Note> {
        val out = mutableListOf<Note>()
        val arr = JSONArray(prefs(c).getString("n", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.optJSONArray("t")
            val rows = mutableListOf<List<String>>()
            if (t != null) {
                for (r in 0 until t.length()) {
                    val ra = t.getJSONArray(r)
                    rows.add((0 until ra.length()).map { ra.getString(it) })
                }
            }
            out.add(Note(o.getLong("id"), o.optString("x"), rows, o.optInt("m"), o.optLong("u")))
        }
        return out.sortedByDescending { it.updated }.toMutableList()
    }

    private fun write(c: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { n ->
            val o = JSONObject()
            o.put("id", n.id)
            o.put("x", n.text)
            o.put("m", n.mode)
            o.put("u", n.updated)
            val t = JSONArray()
            n.table.forEach { row -> t.put(JSONArray(row)) }
            o.put("t", t)
            arr.put(o)
        }
        prefs(c).edit().putString("n", arr.toString()).apply()
    }

    fun get(c: Context, id: Long): Note? = all(c).firstOrNull { it.id == id }

    @Synchronized
    fun save(c: Context, n: Note) {
        n.updated = System.currentTimeMillis()
        val l = all(c)
        l.removeAll { it.id == n.id }
        l.add(n)
        write(c, l)
    }

    @Synchronized
    fun delete(c: Context, id: Long) {
        val l = all(c)
        if (l.removeAll { it.id == id }) write(c, l)
    }
}
