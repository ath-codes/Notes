package com.quicknotes

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotesListActivity : Activity() {

    private var data = mutableListOf<Note>()
    private lateinit var empty: TextView
    private val fmt = SimpleDateFormat("d MMM  h:mm a", Locale.getDefault())

    private val adapter = object : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(position: Int) = data[position]
        override fun getItemId(position: Int) = data[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val n = data[position]
            val box = LinearLayout(this@NotesListActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(14), dp(20), dp(14))
            }
            box.addView(TextView(this@NotesListActivity).apply {
                text = n.title()
                maxLines = 2
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setTextColor(Ui.INK)
                textAlignment = View.TEXT_ALIGNMENT_TEXT_START
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            })
            box.addView(TextView(this@NotesListActivity).apply {
                text = fmt.format(Date(n.updated))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Ui.HINT)
            })
            return box
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BAR
        window.navigationBarColor = Ui.PAGE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.PAGE)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            setPadding(dp(8), 0, dp(8), 0)
        }
        bar.addView(TextView(this).apply {
            text = "→"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setTextColor(Ui.INK)
            gravity = Gravity.CENTER
            minWidth = dp(50)
            minHeight = dp(52)
            setOnClickListener { finish() }
        })
        bar.addView(TextView(this).apply {
            text = "ملاحظاتي"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            setTextColor(Ui.INK)
        })

        val list = ListView(this).apply {
            divider = ColorDrawable(Ui.LINE)
            dividerHeight = dp(1)
            adapter = this@NotesListActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                startActivity(
                    Intent(this@NotesListActivity, MainActivity::class.java)
                        .putExtra("id", data[pos].id)
                )
                finish()
            }
            setOnItemLongClickListener { _, _, pos, _ ->
                AlertDialog.Builder(this@NotesListActivity)
                    .setMessage("حذف هذه الملاحظة؟")
                    .setPositiveButton("حذف") { _, _ ->
                        NoteStore.delete(this@NotesListActivity, data[pos].id)
                        refresh()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
                true
            }
        }
        empty = TextView(this).apply {
            text = "لا توجد ملاحظات بعد"
            setTextColor(Ui.HINT)
            gravity = Gravity.CENTER
            setPadding(0, dp(60), 0, 0)
        }

        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(52)))
        root.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun refresh() {
        data = NoteStore.all(this)
        adapter.notifyDataSetChanged()
        empty.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }
}
