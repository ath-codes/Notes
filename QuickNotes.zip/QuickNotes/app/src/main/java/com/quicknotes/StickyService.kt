package com.quicknotes

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** يعرض ملاحظات لاصقة قابلة للسحب فوق شاشة الهاتف. */
class StickyService : Service() {

    private class Item(
        val root: View,
        val params: WindowManager.LayoutParams,
        val note: Note,
        val edit: EditText
    )

    private lateinit var wm: WindowManager
    private val items = ArrayList<Item>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent?.action == "STOP") {
            removeAll()
            stopSelf()
            return START_NOT_STICKY
        }
        if (Settings.canDrawOverlays(this)) addSticky() else stopSelf()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("sticky", "Sticky notes", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, StickyService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "sticky")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ملاحظات لاصقة نشطة")
            .setContentText("اضغط لفتح التطبيق")
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel, "إغلاق الكل", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addSticky() {
        val note = Note(id = System.currentTimeMillis())
        val r = dp(10).toFloat()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#FFF2A6"), r)
            elevation = dp(6).toFloat()
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F5DC62"))
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        val grip = TextView(this).apply {
            text = "• • •"
            setTextColor(Color.parseColor("#8A7A1E"))
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        }
        val close = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(Color.parseColor("#6B5E10"))
            gravity = Gravity.CENTER
        }
        header.addView(View(this), LinearLayout.LayoutParams(dp(44), dp(40)))
        header.addView(grip, LinearLayout.LayoutParams(0, dp(40), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(44), dp(40)))

        val edit = EditText(this).apply {
            background = null
            hint = "اكتب هنا…"
            setHintTextColor(Color.parseColor("#B8A94E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#33300F"))
            gravity = Gravity.TOP
            textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            maxLines = 10
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }

        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP))

        val lp = WindowManager.LayoutParams(
            dp(220),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(40 + 24 * items.size)
            y = dp(140 + 24 * items.size)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        val item = Item(root, lp, note, edit)

        // سحب الملاحظة من الشريط العلوي
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    if (isFocusable(item)) setFocusable(item, false)
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }

        // الضغط على النص يفتح الكيبورد
        edit.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && !isFocusable(item)) setFocusable(item, true)
            false
        }

        // الضغط خارج الملاحظة يقفل الكيبورد ويحفظ
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && isFocusable(item)) {
                setFocusable(item, false)
                saveItem(item)
            }
            false
        }

        close.setOnClickListener { closeItem(item) }

        items.add(item)
        wm.addView(root, lp)
    }

    private fun isFocusable(s: Item) =
        (s.params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0

    private fun setFocusable(s: Item, on: Boolean) {
        val f = s.params.flags
        s.params.flags = if (on) f and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else f or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (s.root.isAttachedToWindow) wm.updateViewLayout(s.root, s.params)
        val imm = getSystemService(InputMethodManager::class.java)
        if (on) {
            s.edit.postDelayed({
                s.edit.requestFocus()
                imm.showSoftInput(s.edit, InputMethodManager.SHOW_IMPLICIT)
            }, 80)
        } else {
            imm.hideSoftInputFromWindow(s.edit.windowToken, 0)
            s.edit.clearFocus()
        }
    }

    private fun saveItem(s: Item) {
        s.note.text = s.edit.text.toString()
        if (s.note.isEmpty()) NoteStore.delete(this, s.note.id) else NoteStore.save(this, s.note)
    }

    private fun closeItem(s: Item) {
        saveItem(s)
        try { wm.removeView(s.root) } catch (_: Exception) {}
        items.remove(s)
        if (items.isEmpty()) stopSelf()
    }

    private fun removeAll() {
        items.toList().forEach {
            saveItem(it)
            try { wm.removeView(it.root) } catch (_: Exception) {}
        }
        items.clear()
    }

    override fun onDestroy() {
        removeAll()
        super.onDestroy()
    }
}
