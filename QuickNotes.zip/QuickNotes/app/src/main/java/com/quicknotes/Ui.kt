package com.quicknotes

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object Ui {
    val PAGE = Color.parseColor("#FFFBEF")   // لون الصفحة (كريمي فاتح)
    val BAR = Color.parseColor("#F6EFD8")    // الشريط العلوي
    val LINE = Color.parseColor("#C9DCE8")   // خطوط الصفحة المسطرة
    val GRID = Color.parseColor("#D8CFAE")   // خطوط الجدول
    val INK = Color.parseColor("#2B2B2B")    // لون الكتابة
    val HINT = Color.parseColor("#B5AE98")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (stroke > 0) setStroke(stroke, strokeColor)
    }
